# J.A.R.V.I.S. — Core Interface

声で話しかけると、球体が音節ごとに膨らんで応える。

**→ https://USERNAME.github.io/jarvis-orb/**

<!-- 公開したら USERNAME を自分の GitHub アカウント名に置き換えてください -->

---

## これは何

『アイアンマン』の J.A.R.V.I.S. のような音声インターフェース。
three.js で組んだ 5,200 本のフィラメント球が、実際の音声波形にあわせて膨らんで戻ります。

膨らみ方は頂点シェーダで線ごとにバラつかせているので、
球体全体が拡大する「風船」ではなく、表面が逆立つような動きになります。

エンベロープは **立ち上がり 0.40 / 戻り 0.07** の非対称。
ここを対称にすると途端にただの音量メーターに見えます。

## 使い方

開いて **話す (Space)** を押すだけ。

| 何もしなくても | 球体・マイク反応・発話テスト |
| :-- | :-- |
| **API キーを入れると** | 会話が成立する |
| **ローカル版を起動すると** | Whisper + VOICEVOX の高音質版に自動で切り替わる |

- `F` — 全画面
- `Space` — 話しかける
- 3 秒操作しないと UI が消えて球体だけになります

### 会話させる

設定から Anthropic の API キーを入れてください。
キーは **そのブラウザの localStorage にのみ** 保存され、Anthropic の API 以外には送信されません。

キーの発行と失効は [console.anthropic.com](https://console.anthropic.com/settings/keys) から。
共用の PC では入力しないでください。

### 対応ブラウザ

音声認識に Web Speech API を使っているため **Chrome / Edge 推奨** です。
Firefox は音声認識に非対応（球体とマイク反応は動きます）。

---

## ローカル版（高音質）

ブラウザ内蔵の音声認識と音声合成は手軽ですが、精度と声質には限界があります。
`local/jarvis.py` を動かすと、球体が自動でそちらに繋ぎ直します。

- 聞き取り: faster-whisper (large-v3)
- 頭脳: Claude API + Tool use
- 発話: VOICEVOX（低音の男性声を自動で選択）

```bash
pip install anthropic faster-whisper sounddevice numpy requests websockets
export ANTHROPIC_API_KEY=sk-ant-...

# VOICEVOX エンジンを起動してから
python local/jarvis.py
```

起動後にこのページを開くと、右上が `LINK ● LOCAL` に変わります。

声を変えたいときは：

```bash
python local/jarvis.py --voices        # 使える声の一覧
VOICEVOX_SPEAKER=13 python local/jarvis.py
```

マイクは Python 側が持ちます。ブラウザにも取らせると奪い合って両方不安定になるため、
録音中の音量だけを WebSocket で球体に流し、応答の WAV はブラウザ側で再生させています。
再生している当人が波形を解析するので、口の動きと音がずれません。

### 道具を増やす

`local/jarvis.py` の `TOOLS` に関数を足すと、そのぶん JARVIS のできることが増えます。
時刻取得を雛形として入れてあります。

---

## 技術

- [three.js](https://threejs.org/) — WebGL、UnrealBloomPass
- Web Audio API — AnalyserNode による RMS 検出
- Web Speech API — 音声認識・音声合成
- [VOICEVOX](https://voicevox.hiroshiba.jp/)（ローカル版のみ）

## クレジット

VOICEVOX を使って生成した音声を公開する際は、各音声ライブラリの規約に従い
`VOICEVOX:{キャラクター名}` のクレジット表記が必要です。

球体のデザインは映画『アベンジャーズ／エイジ・オブ・ウルトロン』のビジュアルに着想を得た
オリジナル実装です。Marvel および Disney とは一切関係ありません。

## ライセンス

MIT
